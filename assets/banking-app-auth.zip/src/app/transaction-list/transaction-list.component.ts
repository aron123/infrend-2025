import { Component, OnInit, inject } from '@angular/core';
import { TransactionService } from '../services/transaction.service';
import { TransactionDTO } from '../../../models';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-transaction-list',
  standalone: true,
  imports: [DatePipe],
  templateUrl: './transaction-list.component.html',
  styleUrl: './transaction-list.component.css'
})
export class TransactionListComponent implements OnInit {
  transactionService = inject(TransactionService);
  toastrService = inject(ToastrService);
  route = inject(ActivatedRoute);

  transactions: TransactionDTO[] = [];

  ngOnInit(): void {
    const userId = this.route.snapshot.params['userId'];

    this.transactionService.getTransactionsOfUser(userId).subscribe({
      next: (trans) => this.transactions = trans,
      error: err => {
        console.error(err);
        this.toastrService.error('Hiba a betöltés során.', 'Hiba');
      }
    });
  }
}
