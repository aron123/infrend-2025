import { Component, OnInit, inject } from '@angular/core';
import { UserService } from '../services/user.service';
import { UserDTO } from '../../../models';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [],
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css'
})
export class UserListComponent implements OnInit {

  users: UserDTO[] = [];

  userService = inject(UserService);

  router = inject(Router);

  toastrService = inject(ToastrService);

  ngOnInit(): void {
    this.userService.getAll().subscribe({
      next: (users) => this.users = users,
      error: err => console.error(err) 
    });
  }

  listTransactions(id: number) {
    this.router.navigate([ 'transactions-of', id ]);
  }

  editUser(id: number) {
    this.router.navigate([ 'edit-user', id ]);
  }

  deleteUser(id: number) {
    this.userService.delete(id).subscribe({
      next: () => {
        this.toastrService.success('Sikeres törlés', 'Siker')
        const index = this.users.findIndex((user) => user.id == id);
        this.users.splice(index, 1);
      },
      error: (err) => {
        console.error(err);
        this.toastrService.error('Hiba a törlés során.', 'Hiba');
      }
    });
  }

}
