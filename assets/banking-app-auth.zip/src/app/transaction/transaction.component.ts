import { Component, OnInit, inject } from '@angular/core';
import { UserService } from '../services/user.service';
import { CategoryService } from '../services/category.service';
import { CategoryDTO, TransactionDTO, UserDTO } from '../../../models';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TransactionService } from '../services/transaction.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-transaction',
  standalone: true,
  imports: [ FormsModule, ReactiveFormsModule ],
  templateUrl: './transaction.component.html',
  styleUrl: './transaction.component.css'
})
export class TransactionComponent implements OnInit {
  
  userService = inject(UserService);
  categoryService = inject(CategoryService);
  transactionService = inject(TransactionService);
  toastrService = inject(ToastrService);
  
  fb = inject(FormBuilder);

  transactionForm = this.fb.group<TransactionDTO>({
    id: 0,
    source: null,
    destination: null,
    amount: 1,
    categories: [],
    transactionDate: ''
  });

  users: UserDTO[] = [];
  categories: CategoryDTO[] = [];

  ngOnInit(): void {
    this.userService.getAll().subscribe({
      next: (users) => this.users = users
    });

    this.categoryService.getAll().subscribe({
      next: (categories) => this.categories = categories
    });
  }

  sendTransaction() {
    const transaction = this.transactionForm.value;
    this.transactionService.create(transaction as TransactionDTO).subscribe({
      next: () => this.toastrService.success('Tranzakció végrehajtva!', 'Siker'),
      error: (err) => {
        console.error(err);
        this.toastrService.error('Tranzakció nem sikerült.', 'Hiba');
      }
    });
  }
}
