import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { UserDTO } from '../../../models';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-user-form',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './user-form.component.html',
  styleUrl: './user-form.component.css'
})
export class UserFormComponent implements OnInit {
  
  fb = inject(FormBuilder);

  route = inject(ActivatedRoute);

  router = inject(Router);

  toastrService = inject(ToastrService);

  userService = inject(UserService);

  userForm = this.fb.group<UserDTO>({
    id: 0,
    customerId: '0',
    name: '',
    address: '',
    phone: '',
    idCard: ''
  });

  isNewUser = true;

  ngOnInit(): void {
    this.userForm.get('customerId')?.disable();

    const id = this.route.snapshot.params['id'];

    if (id) {
      this.isNewUser = false;
      this.userService.getOne(id).subscribe({
        next: user => this.userForm.setValue(user),
        error: (err) => this.toastrService.error('Hiba a felhasználók betöltésekor', 'Hiba')
      });
    }
  }

  saveUser() {
    const user = this.userForm.value;

    if (this.isNewUser) {
      this.userService.create(user as UserDTO).subscribe({
        next: () => {
          this.toastrService.success('Sikeres mentés', 'Siker');
          this.router.navigateByUrl('/user-list');
        },
        error: (err) => {
          console.error(err);
          this.toastrService.error('Hiba a mentés során.', 'Hiba')
        }
      });
    } else {
      this.userService.update(user as UserDTO).subscribe({
        next: () => {
          this.toastrService.success('Sikeres mentés', 'Siker');
          this.router.navigateByUrl('/user-list');
        },
        error: (err) => {
          console.error(err);
          this.toastrService.error('Hiba a mentés során.', 'Hiba')
        }
      });
    }
  }
}
