import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { CategoryDTO } from '../../../models';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  http = inject(HttpClient);

  getAll() {
    return this.http.get<CategoryDTO[]>('/api/category');
  }
}
