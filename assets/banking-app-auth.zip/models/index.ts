export interface UserDTO {
    id: number;
    customerId: string;
    name: string;
    address: string;
    phone: string;
    idCard: string;
}

export interface TransactionDTO {
    id: number;
    transactionDate: string;
    source: UserDTO|null;
    destination: UserDTO|null;
    amount: number;
    categories: CategoryDTO[] | null;
}

export interface CategoryDTO {
    id: number;
    title: string;
}