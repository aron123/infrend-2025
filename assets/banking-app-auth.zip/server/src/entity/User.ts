import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm"
import { Transaction } from "./Transaction";
import { UserDTO } from "../../../models";

@Entity()
export class User implements UserDTO {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column()
    customerId: string;

    @Column()
    address: string;

    @Column()
    phone: string;

    @Column()
    idCard: string;

    @OneToMany(type => Transaction, transaction => transaction.source)
    outgoingTransactions: Transaction[];

    @OneToMany(type => Transaction, transaction => transaction.destination)
    incomingTransactions: Transaction[];
}
